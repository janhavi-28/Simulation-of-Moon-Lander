﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Hypermedia.AspNetCore")]
[assembly: InternalsVisibleTo("Hypermedia.JsonApi.AspNetCore")]
[assembly: InternalsVisibleTo("Hypermedia.WebApi")]
[assembly: InternalsVisibleTo("Hypermedia.JsonApi.WebApi")]
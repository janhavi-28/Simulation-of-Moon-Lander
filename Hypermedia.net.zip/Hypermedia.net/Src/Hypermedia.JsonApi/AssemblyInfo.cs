﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Hypermedia.JsonApi.AspNetCore")]
[assembly: InternalsVisibleTo("Hypermedia.JsonApi.WebApi")]
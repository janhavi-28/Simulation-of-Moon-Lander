﻿namespace Hypermedia.Sample.Data
{
    public interface IUserRepository : IRepository<User> { }
}
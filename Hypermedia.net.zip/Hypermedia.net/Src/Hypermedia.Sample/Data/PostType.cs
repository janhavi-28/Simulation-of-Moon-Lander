﻿namespace Hypermedia.Sample.Data
{
    public enum PostType
    {
        Questions = 1,
        Answers = 2,
        Others = 3,
    }
}

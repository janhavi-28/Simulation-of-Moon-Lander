﻿namespace Hypermedia.WebApi
{
    public enum SortDirection
    {
        Ascending,
        Descending
    }
}
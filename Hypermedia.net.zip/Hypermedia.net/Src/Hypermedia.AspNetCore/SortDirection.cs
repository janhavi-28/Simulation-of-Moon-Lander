﻿namespace Hypermedia.AspNetCore
{
    public enum SortDirection
    {
        Ascending,
        Descending
    }
}
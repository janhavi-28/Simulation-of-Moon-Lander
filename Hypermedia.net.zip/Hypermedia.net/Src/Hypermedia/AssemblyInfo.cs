﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Hypermedia.WebApi")]
[assembly: InternalsVisibleTo("Hypermedia.AspNetCore")]
[assembly: InternalsVisibleTo("Hypermedia.Json")]
[assembly: InternalsVisibleTo("Hypermedia.JsonApi")]
[assembly: InternalsVisibleTo("Hypermedia.JsonApi.Client")]
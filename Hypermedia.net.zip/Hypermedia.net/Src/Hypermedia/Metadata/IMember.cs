﻿namespace Hypermedia.Metadata
{
    public interface IMember
    {
        /// <summary>
        /// Gets the name of the member.
        /// </summary>
        string Name { get; }
    }
}
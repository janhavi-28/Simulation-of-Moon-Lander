namespace Hypermedia.Metadata
{
    public interface IHasManyRelationship : IRelationship { }
}
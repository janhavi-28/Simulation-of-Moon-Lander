# Code of Conduct

In order to contribute to this project, you are asked to subscribe to the Lunduke Code of Conduct, which is replicated in full below.

Violations of this policy will result in you being barred from interacting with this repository or its community.

This shouldn't be difficult.

## The Lunduke Code of Conduct

Be excellent to eachother.